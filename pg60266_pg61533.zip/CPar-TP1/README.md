# zpic_CompParalela
This repository holds the files for the Computação Paralela Course (2025-2026)
